// import React, { useState } from 'react';

// const ApplicationForm = () => {
//     const [name, setName] = useState('');
//     const [email, setEmail] = useState('');
//     const [cv, setCv] = useState(null);

//     const handleSubmit = async (e) => {
//         e.preventDefault();


//         const formData = new FormData();
//         formData.append('username', name);
//         formData.append('email', email);
//         formData.append("cv", cv);



//         try {
//             await fetch("http://192.168.1.165:8000/submit", {
//                 method: "POST",
//                 headers: {
//                     "Content-Type": "application/json"
//                 },
//                 body: JSON.stringify({ username: name, email: email })  // öz inputlara uyğun
//             });

//             if (!response.ok) {
//                 throw new Error('Failed to submit');
//             }

//             const data = await response.json();
//             alert(data.message);

//             // Formu təmizlə
//             setName('');
//             setEmail('');

//         } catch (error) {
//             console.error('Error submitting form:', error);
//             alert('Error submitting form');
//         }
//     };



//     return (
//         <div style={{
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'center',
//             justifyContent: 'flex-start',
//             paddingTop: '50px',
//             height: '100vh',
//             boxSizing: 'border-box',
//         }}>
//             <h1>Application Form</h1>

//             <form onSubmit={handleSubmit}
//                 style={{
//                     alignItems: 'center',
//                     justifyContent: 'center',
//                     border: '1px solid #333', // kənar xətt
//                     borderRadius: '10px',
//                     padding: '30px',
//                     backgroundColor: '#fff',
//                     boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
//                     width: '200px',
//                     height: '250px',
//                     display: 'flex',
//                     flexDirection: 'column',
//                     gap: '15px'
//                 }}>

//                 <div style={{ marginBottom: '10px' }}>
//                     <label>Name:</label><br />
//                     <input
//                         type="text"
//                         value={name}
//                         onChange={(e) => setName(e.target.value)}
//                         placeholder="Enter your name"
//                         style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
//                     />
//                 </div>

//                 <div style={{ marginBottom: '10px' }}>
//                     <label>Email:</label><br />
//                     <input
//                         type="email"
//                         value={email}
//                         onChange={(e) => setEmail(e.target.value)}
//                         placeholder="Enter your email"
//                         style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
//                     />
//                 </div>



//                 <button
//                     type="submit"
//                     style={{
//                         padding: '10px 20px',
//                         fontSize: '16px',
//                         backgroundColor: '#007bff',
//                         color: '#fff',
//                         border: 'none',
//                         borderRadius: '5px',
//                         cursor: 'pointer'
//                     }}
//                 >
//                     Submit
//                 </button>
//             </form>
//         </div>
//     );
// };

// export default Application;


import React, { useState } from 'react';

const ApplicationForm = () => {
    const [name, setName] = useState(''); 8888888
    const [email, setEmail] = useState('');
    const [cv, setCv] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('username', name);
        formData.append('email', email);
        formData.append('cv', cv);

        try {
            const response = await fetch("http://192.168.1.165:8000/submit", {
                method: "POST",
                body: formData
            });

            if (!response.ok) {
                throw new Error('Failed to submit');
            }

            const data = await response.json();
            alert(data.message || 'Submitted successfully!');

            // Formu təmizlə
            setName('');
            setEmail('');
            setCv(null);

        } catch (error) {
            console.error('Error submitting form:', error);
            alert('Error submitting form');
        }
    };

    return (
        <div className="wrapper">
            <h1>Application Form</h1>

            <form onSubmit={handleSubmit} className="formContainer"
            >

                <div>
                    <label>Name:</label><br />
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter your name"

                    />
                </div>

                <div>
                    <label>Email:</label><br />
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"

                    />
                </div>

                <div>
                    <label>Resume</label><br />
                    <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => setCv(e.target.files[0])}
                        required
                        placeholder="No file chose"
                    />
                </div>

                <button
                    type="submit"

                >
                    Submit
                </button>
            </form>
        </div>
    );
};

export default ApplicationForm;