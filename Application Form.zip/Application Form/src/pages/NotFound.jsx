// import React from 'react'
// import mailImage from '../assets/mail.jpg'

// const NotFound = () => {
//     return (
//         <div style={{
//             display: 'flex',
//             justifyContent: 'center',
//             alignItems: 'flex-start',
//             height: '100vh'
//         }}>
//             <h1>Mini Intership Portal</h1>

//             <img
//                 src={mailImage}
//                 alt="My Uploaded"
//                 style={{
//                     marginTop: '20px',
//                     width: '400px',
//                     height: 'auto',
//                     borderRadius: '8px',
//                     display: 'block',
//                     marginLeft: 'auto',
//                     marginRight: 'auto'
//                 }}
//             />
//         </div>

//     )
// }

// export default NotFound
import React from 'react'

const NotFound = () => {
    return (
        <div style={{
            display: 'flex',
            justifyContent: 'center',
            // alignItems: 'flex-start',
            paddingTop: '100px',
            height: '100vh',
            fontSize: '50px',
        }}>
            Belə bir səyfə tapılmadı
        </div>
    )
}

export default NotFound
