// import React from 'react'

// const About = () => {
//     return (
//         <div
//             style={{
//                 display: 'flex',
//                 flexDirection: 'column',
//                 alignItems: 'center',
//                 justifyContent: 'flex-start',
//                 paddingTop: '50px',
//                 height: '100vh',
//                 boxSizing: 'border-box',
//             }}>

//             <h1 style={{ marginBottom: '0px' }}>Application Form</h1>

//         </div>
//     )
// }

// export default About


import React, { useState } from 'react';

const About = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [cv, setCv] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();


        const formData = new FormData();
        formData.append('username', name);
        formData.append('email', email);
        formData.append("cv", cv);



        try {
            await fetch("http://192.168.1.165:8000/submit", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ username: name, email: email })  // öz inputlara uyğun
            });

            if (!response.ok) {
                throw new Error('Failed to submit');
            }

            const data = await response.json();
            alert(data.message);

            // Formu təmizlə
            setName('');
            setEmail('');

        } catch (error) {
            console.error('Error submitting form:', error);
            alert('Error submitting form');
        }
    };



    return (
        <div >
            <h1>Application Form</h1>

            <form onSubmit={handleSubmit}
            >

                <div style={{ marginBottom: '10px' }}>
                    <label>Name:</label><br />
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter your name"

                    />
                </div>

                <div style={{ marginBottom: '10px' }}>
                    <label>Email:</label><br />
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"

                    />
                </div>



                <button
                    type="submit"
                >
                    Submit
                </button>
            </form>
        </div>
    );
};

export default About;