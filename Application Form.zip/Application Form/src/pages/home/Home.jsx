import React from 'react';
import { useNavigate } from 'react-router-dom';
import mailImage from '../../assets/mail.jpg';
import "../../assets/css/home/Home.css"

const Home = () => {
    const navigate = useNavigate();

    const handleApplyClick = () => {
        navigate('/application');
    };


    return (
        <div className='wrapper'

        >
            <h1 >Mini Internship Portal</h1>

            <img
                src={mailImage}
                alt="My Uploaded"
            />

            <p>Welcome to the Internship portal!<br />
                Apply for internships with ease.
            </p>

            <button onClick={handleApplyClick}
            >
                Apply Now
            </button>


        </div>
    );
};

export default Home;

