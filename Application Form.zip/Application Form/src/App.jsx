import React, { useState } from 'react';
import axios from 'axios';
import { Routes, Route } from "react-router-dom";
import Home from './pages/home/Home';
import About from './pages/about/About';
import ApplicationForm from './assets/application/ApplicationForm';
import NotFound from './pages/NotFound';

const API_BASE = "http://192.168.1.166:8000"; // backend URL

function App() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [cv, setCv] = useState(null);
  const [adminName, setAdminName] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [applicants, setApplicants] = useState([]);
  const [loggedIn, setLoggedIn] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [status, setStatus] = useState('');

  const submitUser = async () => {
    const formData = new FormData();
    formData.append("username", username);
    formData.append("email", email);
    formData.append("cv", cv);

    try {
      await axios.post(`${API_BASE}/submit`, formData);
      alert("CV submitted successfully");
    } catch (err) {
      alert("Error submitting CV");
    }
  };

  const loginAdmin = async () => {
    try {
      const res = await axios.post(`${API_BASE}/admin`, {
        name: adminName,
        password: adminPass
      });
      setApplicants(res.data.applicants);
      setLoggedIn(true);
    } catch (err) {
      alert("Login failed");
    }
  };

  const updateStatus = async (id) => {
    try {
      await axios.put(`${API_BASE}/admin/applicants/${id}/status`, {
        status: status
      });
      alert("Status updated");
    } catch (err) {
      alert("Error updating status");
    }
  };

  const downloadCv = async (id) => {
    try {
      const res = await axios.get(`${API_BASE}/admin/applicants/${id}/download`, {
        responseType: 'blob'
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `cv_${id}.pdf`);
      document.body.appendChild(link);
      link.click();
    } catch (err) {
      alert("Error downloading CV");
    }
  };

  return (
    // <div style={{ padding: '20px' }}>
    //   <h1>Internship Portal</h1>

    //   <h2>Submit CV</h2>
    //   <input type="text" placeholder="Name" value={username} onChange={e => setUsername(e.target.value)} /><br />
    //   <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><br />
    //   <input type="file" onChange={e => setCv(e.target.files[0])} /><br />
    //   <button onClick={submitUser}>Submit</button>

    //   <hr />

    //   <h2>Admin Login</h2>
    //   <input type="text" placeholder="Admin name" value={adminName} onChange={e => setAdminName(e.target.value)} /><br />
    //   <input type="password" placeholder="Password" value={adminPass} onChange={e => setAdminPass(e.target.value)} /><br />
    //   <button onClick={loginAdmin}>Login</button>

    //   {loggedIn && (
    //     <>
    //       <h2>Applicant List</h2>
    //       {applicants.map(app => (
    //         <div key={app.id} style={{ border: '1px solid gray', marginBottom: '10px', padding: '10px' }}>
    //           <p><strong>ID:</strong> {app.id}</p>
    //           <p><strong>Name:</strong> {app.name}</p>

    //           <input placeholder="new status (approved/rejected/pending)" onChange={e => setStatus(e.target.value)} />
    //           <button onClick={() => updateStatus(app.id)}>Change Status</button>
    //           <button onClick={() => downloadCv(app.id)}>Download CV</button>
    //         </div>
    //       ))}
    //     </>
    //   )}
    // </div>

    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="about" element={<About />} />
      <Route path="application" element={<ApplicationForm />} />

      <Route path="*" element={<NotFound />} />
    </Routes>

  );
}

export default App;
